from django.db import models

class student(models.Model):
    stdid=models.IntegerField(primary_key=True)
    stuname=models.CharField(max_length=50)
    stuemail=models.CharField(max_length=50)
    stupass=models.CharField(max_length=10)

    #def __str__(self):
        #return self.stuname
class login(models.Model):
    user_name=models.CharField(max_length=50)
    password=models.CharField(max_length=50)

