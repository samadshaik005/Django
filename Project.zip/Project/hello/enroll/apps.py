from django.apps import AppConfig


class EnrollConfig(AppConfig):
    name = 'enroll'
