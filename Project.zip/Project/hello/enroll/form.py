from django import forms

class studentreg(forms.Form):
    studentid=forms.IntegerField()
    name=forms.CharField()
    email=forms.EmailField()
    password=forms.PasswordInput()
