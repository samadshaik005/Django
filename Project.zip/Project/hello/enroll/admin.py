from django.contrib import admin
from .models import student


#admin.site.register(student)

# Register your models here.

class studentadmin(admin.ModelAdmin):
    list_display = ('stdid','stuname','stuemail','stupass')
admin.site.register(student,studentadmin)

#------------
from .models import login
class usertable(admin.ModelAdmin):
    list_display = ('user_name','password')
admin.site.register(login,usertable)