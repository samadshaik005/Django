from django.urls import path
from . import views

urlpatterns=[
    #path('',views.studentinfo,name='s'),
    #path('reg/',views.showformdata,name='s1'),
    path('',views.register,name='s2'),
    path('register',views.register,name='s3'),
]