from django.shortcuts import render,redirect
from .models import student



def studentinfo(request):
    stdobj=student.objects.all()  #objects.pk(1) or #objects.pk(2) for specific object
    return render(request, 'sindex.html',{'std':stdobj})

#-------------------------------------------------------
#fetch from db
from .form import studentreg
def showformdata(request):
    fm=studentreg
    return render(request,'formdisplay.html',{'fr':fm})
#------------------------------------------------------------------
#insert into db
from .models import login
#from django.contrib import messages

def register(request):
    if(request.method=='POST'):
        uname=request.POST['name']
        #messages.info(request,'username taken')
        #return redirect('register')
        upass=request.POST['pass']
        userobj=login(user_name=uname,password=upass)
        userobj.save();
        print("object created")
        return redirect('/')
    else:
        return render(request,'formtodb.html')

    #user=user.objects.

