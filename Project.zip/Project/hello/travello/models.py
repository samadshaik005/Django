from django.db import models

class Destination:
    id:int
    name:str
    img:str
    desc:str
    price:int
    offer:bool

# Create your models here.
