import numpy as np
import cv2

image=cv2.imread('./image_examples/Modi.jpg')

img_scaled=cv2.resize(image,None,fx=0.75,fy=0.75)
cv2.show('scaling :linear interpolation',img_scaled)
cv2.waitkey(0)