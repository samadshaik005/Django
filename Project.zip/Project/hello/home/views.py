from django.shortcuts import render
from django.http import HttpResponse
def index(request):
    #return HttpResponse("hello world");
    #return render(request,'home.html')
    return render(request, 'home.html',{'name':'sam'})
def sum(request):
    a=int(request.POST['first'])
    b=int(request.POST['last'])
    res=a+b
    return render(request,'result.html',{'result':res})

# Create your views here.
